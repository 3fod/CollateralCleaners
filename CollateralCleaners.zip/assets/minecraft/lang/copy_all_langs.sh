while IFS= read -r line; do
    cp en_us.json "${line}.json"
done <<< $(cat languagelist.txt | grep -v "^$")
